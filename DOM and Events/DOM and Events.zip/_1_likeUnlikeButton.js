function changeName() {
	if (document.getElementById('but').innerText == "Like") {
		document.getElementById('but').innerText = "Unlike";
	} else {
		document.getElementById('but').innerText = "Like";
	}
}
